var data = [
  {
    "name":  "Sukanta Bala",
    "email": "sukantabala2016@gmail.com",
    "password": "Sukanta_Bala_28"
  }
]

module.exports = {
  "data" : data
}